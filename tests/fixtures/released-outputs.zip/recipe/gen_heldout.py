"""What the released TEST scorer (scripts/test_eval_20260924_score.py) gives for tests/test_evaluate_heldout.py.

usage (repository root, old code in place): .venv/bin/python .scratch/gen_heldout.py OUT_FOLDER
Writes OUT_FOLDER/heldout-released.json with:
  without_predictions, with_predictions : the scorer's results for the two row roots of the test
  pick_rule : {case: decision}, eligibility : {case: [ok, reasons]}
"""

import copy
import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path

REPO = Path.cwd()
sys.path.insert(0, str(REPO / "tests"))
sys.path.insert(0, str(REPO))

import pytest  # noqa: E402
import test_evaluate_heldout as T  # noqa: E402

ZIB = "/home/nimtsspi/taxonomy/test-eval-20260924"

before = dict(os.environ)
spec = importlib.util.spec_from_file_location(
    "old_test_eval_score", REPO / "scripts/test_eval_20260924_score.py"
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
os.environ.clear()
os.environ.update(before)
module.PLAN = T.TEST_EVAL / "plan.json"


def stable(result: dict, root: Path) -> dict:
    text = json.dumps(result)
    for local, zib in ((str(T.TEST_EVAL), ZIB), (str(root / T.ROWS), f"{ZIB}/rows")):
        text = text.replace(local, zib)
    return json.loads(text)


out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
data = {}
for name, with_predictions in (("without_predictions", False), ("with_predictions", True)):
    with tempfile.TemporaryDirectory() as tmp:
        work, root, smoke = T.heldout_setup(Path(tmp), with_predictions=with_predictions)
        mp = pytest.MonkeyPatch()
        try:
            result = T.released_results(module, root, mp, smoke)
        finally:
            mp.undo()
        data[name] = stable(result, root)
data["pick_rule"] = {
    case: module.apply_pick_rule(copy.deepcopy(rows), 100)
    for case, rows, _ in T.PICK_CASES
}
cases = {}
for case, status, papers, _ in T.ELIGIBILITY_CASES:
    row = {"status": status, "papers": {str(i): [] for i in range(papers)}, "errors": []}
    ok, reasons = module.eligibility(copy.deepcopy(row), 29)
    cases[case] = [ok, reasons]
data["eligibility"] = cases
(out / "heldout-released.json").write_text(json.dumps(data, indent=1, ensure_ascii=False) + "\n")
print("ok")
