"""What the released grid scorer (scripts/grid_20260925_score.py) gives on the miniature grid.

usage (repository root, old code in place): .venv/bin/python .scratch/gen_grid.py OUT_FOLDER
Writes under OUT_FOLDER:
  grid-mini-results.json   `evaluate` + `add_replicate` on the miniature grid (test_evaluate_grid.py)
  grid-mini-environment.json  the environment values importing the scorer sets
  row3/scoring/*           the released scoring run's files on the miniature grid, first audit, ZIB paths
  row3/reselect/*          its reselection with the corrected audit (test_check_selection.py)
"""

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

REPO = Path.cwd()
sys.path.insert(0, str(REPO / "tests"))
sys.path.insert(0, str(REPO))

import test_check_selection as C  # noqa: E402
from mini_grid import audit_labels, make_grid, write_audit  # noqa: E402
from released_grid import (  # noqa: E402
    OPUS_CALLS,
    TEST_RESULTS,
    released_code,
    released_references,
)

from taxonomy_pipeline.evaluate import grid, selection  # noqa: E402

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)

# 1. test_evaluate_grid.py's `released` fixture
with tempfile.TemporaryDirectory() as tmp:
    folder = Path(tmp)
    roots = make_grid(folder)
    audit = write_audit(folder / "audit.json")
    results = folder / "test-results.json"
    results.write_text(json.dumps(TEST_RESULTS))
    with released_code() as (old, environment):
        result = old.evaluate(
            roots["grid"],
            released_references(REPO),
            workers=1,
            opus_test_calls=OPUS_CALLS,
            audit_path=audit,
            trained_roots=[roots["trained"]],
            extra_audits=[],
        )
        old.add_replicate(result, results)
    text = json.dumps(json.loads(json.dumps(result, default=str)), indent=1, ensure_ascii=False)
    text = text.replace(tmp, "@MINI@")  # the temporary folder, put back by the test
    assert "/tmp" not in text and "pytest-of" not in text, "a temporary path is left"
    (out / "grid-mini-results.json").write_text(text + "\n")
    (out / "grid-mini-environment.json").write_text(json.dumps(environment, indent=1) + "\n")

# 2. test_check_selection.py's `row3`: the stored outputs the released code made
with tempfile.TemporaryDirectory() as tmp:
    tmp_path = Path(tmp)
    root, repo = tmp_path / "data-root", tmp_path / "repo"
    repo.mkdir()
    shutil.copytree(REPO / "data/frozen/results", repo / "data/frozen/results")
    write_audit(repo / selection.AUDIT.replace("frozen/", "data/frozen/", 1))
    made = make_grid(tmp_path / "made")
    roots = {"grid": root / grid.GRID, "trained": root / grid.TRAINED}
    for name, target in roots.items():
        target.parent.mkdir(parents=True, exist_ok=True)
        made[name].rename(target)
    results = root / grid.TEST_RESULTS
    results.parent.mkdir(parents=True, exist_ok=True)
    results.write_text(json.dumps(TEST_RESULTS))
    first = tmp_path / "first-audit.json"
    write_audit(first)
    value = json.loads(first.read_text())
    for label in audit_labels():
        if "/TR-" in label:
            value["cohorts"][label] = {"verdict": "defect", "reasons": ["false positive"]}
    first.write_text(json.dumps(value))
    scoring = root / selection.SCORING_RUN
    with released_code() as (old, environment):
        result = old.evaluate(
            roots["grid"],
            released_references(repo),
            workers=1,
            opus_test_calls=OPUS_CALLS,
            audit_path=first,
            trained_roots=[roots["trained"]],
            extra_audits=[],
        )
        old.add_replicate(result, results)
        written = old.write_outputs(result, tmp_path / "score")
        C.as_zib(written, root)
        scoring.parent.mkdir(parents=True, exist_ok=True)
        written.rename(scoring)
        old.cmd_reselect(
            argparse.Namespace(
                results=scoring / "results.json",
                audit=repo / "data/frozen/results/grid-20260925/audit/audit.json",
                out=tmp_path / "reselect",
                reason=selection.RESELECT_REASON,
            )
        )
    reselected = next((tmp_path / "reselect/runs").iterdir())
    C.as_zib(reselected, root)
    for name, folder in (("scoring", scoring), ("reselect", reselected)):
        target = out / "row3" / name
        target.mkdir(parents=True, exist_ok=True)
        for path in sorted(folder.iterdir()):
            text = path.read_bytes()
            text = text.replace(tmp.encode(), b"@TMP@")  # put back by the test
            assert b"/tmp/" not in text and b"pytest-of" not in text, path
            print(name, path.name, len(text), text.count(b"@TMP@"), "placeholders")
            (target / path.name).write_bytes(text)
print("ok")
