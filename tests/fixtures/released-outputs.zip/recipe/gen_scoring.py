"""Make the stored outputs of the released scorers on the miniature inputs (run before #66 deletes them).

usage (from the repository root, with the old code still in place):
    .venv/bin/python .scratch/gen_scoring.py OUT_FOLDER

Writes OUT_FOLDER/heldout-mini-results.json, heldout-mini-results.md (rows 4's miniature rescoring by
scripts/test_eval_20260924_score.py, ZIB paths written in as the stored copies have them) and
paired-mini-output.txt (scripts/paired_ours_vs_opus.py on tests/mini_scoring.paired_inputs).
"""

import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path.cwd()
sys.path.insert(0, str(REPO / "tests"))
sys.path.insert(0, str(REPO))

import pytest  # noqa: E402
from mini_scoring import (  # noqa: E402
    PAIRED_PATHS,
    heldout_inputs,
    paired_inputs,
    released_heldout,
)

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    root = tmp / "data-root"
    heldout_inputs(tmp / "repo", root)
    mp = pytest.MonkeyPatch()
    try:
        results, markdown = released_heldout(root, mp)
    finally:
        mp.undo()
    (out / "heldout-mini-results.json").write_bytes(results)
    (out / "heldout-mini-results.md").write_bytes(markdown)

    a = paired_inputs(tmp / "a", None)
    b = paired_inputs(tmp / "b", PAIRED_PATHS)
    outs = []
    for inputs in (a, b):
        done = subprocess.run(
            [sys.executable, str(REPO / "scripts/paired_ours_vs_opus.py"), *map(str, inputs)],
            capture_output=True,
            check=True,
        )
        outs.append(done.stdout)
    assert outs[0] == outs[1], "the two input layouts give different output"
    (out / "paired-mini-output.txt").write_bytes(outs[0])
print("ok")
