# TEST evaluation results (29 held-out papers)

Created 2026-10-20T09:12:17.166272+00:00. Reference: 29 papers with 365 reference definitions. A predicted definition counts as a match when the frozen definition matcher pairs it one-to-one with a reference definition of the same paper at similarity 0.50 or more.

Precision = matches / predicted definitions. Recall = matches / all reference definitions. Full-record score = average per-paper agreement over all record fields (terms, definitions, synonyms, and so on).

| Row | Model family | Matches / predicted | Precision | Recall | F1 | Full-record | Papers with output | Failed windows | Failed verifier batches | Requests | Cost (USD) | Eligible |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| R0bea6bc | Qwen | 0 / 0 | 0.0% | 0.0% | 0.0% | 0.000 | 29/29 | 0/90 | 0/40 | 130 | 0 | yes |
| R6e24b3d | Qwen | missing | | | | | | | | | | no (not produced by the deadline) |
| Ra1da1ae | Qwen | missing | | | | | | | | | | no (not produced by the deadline) |
| QWEN-POOL3 | Qwen | 0 / 0 | 0.0% | 0.0% | 0.0% | 0.000 | 29/29 | 0/90 | 0/40 | 130 | 0 | yes |
| Rdb54680 | Opus | 0 / 0 | 0.0% | 0.0% | 0.0% | 0.000 | 29/29 | 0/90 | 0/40 | 130 | 41.28007 | yes |
| R80dd4ae | Opus | missing | | | | | | | | | | no (not produced by the deadline) |
| R9ec8007 | Opus | missing | | | | | | | | | | no (not produced by the deadline) |
| R13f6cd1 | Kimi | missing | | | | | | | | | | no (not produced by the deadline) |
| Rde76462 | Sol | 0 / 0 | 0.0% | 0.0% | 0.0% | 0.000 | 29/29 | 0/90 | 0/40 | 130 | 0 | no (status.complete is not true) |
| R906aabe | SOOFI | missing | | | | | | | | | | no (not produced by the deadline) |
| R8ce2900 | Gemma 12B | missing | | | | | | | | | | no (not produced by the deadline) |
| R74933e3 | Gemma 12B | missing | | | | | | | | | | no (not produced by the deadline) |

Row descriptions (from the frozen plan):

- R0bea6bc (Qwen, self-hosted): two GEPA prompts (16k/2k, 32k/4k chars), chat format 8192 out, strict Qwen verifier, title-aware relevance cutoff 0.2371840437933272
- R6e24b3d (Qwen, self-hosted): same extraction+verifier as R0bea6bc, relevance without title features
- Ra1da1ae (Qwen, self-hosted): same extraction+verifier as R0bea6bc, separate-title relevance
- QWEN-POOL3 (Qwen, self-hosted): NEW recipe declared 2026-09-24 from the DEV pooling audit: three passes on one BF16 server (chat 8192, JSON-schema 8192, JSON-schema 16384), each with the strict verifier and title-aware relevance; final records merged with src.extractor.merge
- Rdb54680 (Opus, OpenRouter): Opus native Bootstrap program (8k/1k chars, high reasoning, 8192 out) + common Qwen strict verifier
- R80dd4ae (Opus, OpenRouter): same Opus extraction + Qwen strict verifier + frozen TRAIN relevance
- R9ec8007 (Opus, OpenRouter): Opus with transferred Qwen F1 GEPA prompt (32k/4k, high reasoning, 16384 out) + Qwen strict verifier + frozen TRAIN relevance
- R13f6cd1 (Kimi, OpenRouter): Kimi K3 with transferred Gemma recall prompt (32k/4k, high reasoning, 16384 out), source cleanup and exact merge
- Rde76462 (Sol, OpenRouter): GPT-5.6 Sol with transferred Gemma F1 (MIPRO heavy) prompt (32k/4k, high reasoning, 16384 out), source cleanup and exact merge
- R906aabe (SOOFI, free academic endpoint): SOOFI native Bootstrap program (8k/1k, temperature 0.6, 32768 out) via Passau academic endpoint
- R8ce2900 (Gemma 12B, self-hosted): Gemma 4 12B QAT native Bootstrap program (8k/1k, temperature 0.6, 32768 out), self-hosted
- R74933e3 (Gemma 12B, self-hosted): Gemma 4 12B MIPRO heavy program (32k/4k, temperature 0, 8192 out) + Qwen strict verifier + frozen TRAIN relevance, self-hosted

## Pick

Rule (frozen before any TEST result): Among eligible rows with TEST recall >= 80%, pick the highest precision, but prefer a self-hosted Qwen row if its recall is within 2 matches of the leader. If no row reaches 80%, pick the highest recall among rows with precision >= 15%. Report every row either way.

Eligibility rule: A row is eligible for the pick only if every paper produced output and at most 5% of its extraction windows / verifier batches failed. Failed windows or batches contribute no records and are counted and reported; missing verifier verdicts reject that candidate. No model-output retries beyond each recipe's historical documented policy.

**Pick: none.** No eligible row reaches 80% recall and none has precision >= 15%; no row can be picked.

## Caveats

- All DEV numbers for these rows are best-of-many DEV selections and are optimistic; TEST is the first held-out estimate.
- Each row is one generation; single-run spread on DEV was about +/-3 matches for Qwen, so differences under ~5 matches are not meaningful.
