# Final picks (plan amendment 8): three TEST precision floors

**These picks were chosen on TEST, so their TEST numbers are optimistic estimates, not held-out results.** DEV numbers of the same configs are shown beside them.

| Floor | Pick | TEST matches/predicted | TEST precision | TEST recall | DEV matches/predicted | DEV precision | DEV recall | LLM calls (TEST) |
|---|---|---|---|---|---|---|---|---|
| P>=20 | none | | | | | | | |
| P>=24 | none | | | | | | | |
| P>=28 | none | | | | | | | |

Each pick's exact rebuild recipe (cohort parts, stage, pool) is in results.json under final_picks.

# Controlled model grid: Qwen 3.6 35B vs Gemma 4 12B

Created 2026-10-20T09:13:48.653914+00:00. Frozen plan SHA-256 5604ef104203.

A predicted definition counts as a match when the frozen definition matcher pairs it one-to-one with a reference definition of the same paper at similarity 0.50 or more. Precision = matches / predicted definitions; recall = matches / all reference definitions of the split.

- DEV reference: 21 papers, 115 definitions
- TEST reference: 29 papers, 365 definitions

## Superseded: fewest-calls TEST pick (plan amendment 5, replaced by amendment 8)

Rule: Across all eligible configs (grid, thinking, and trained-program configs from training-20260925): among configs with TEST matches >= 290 of 365 (matches or beats Opus Rdb54680 at 290/1002), pick the fewest LLM calls (extraction + verifier, including fallbacks); configs within 10% of the fewest are tied and the tie goes to higher TEST precision. If none reaches 290, pick the highest TEST recall with TEST precision >= 15%. DEV results are reported next to every config.

LLM calls = extraction requests (including every automatic format-fallback request) + requests of the verifier the stage uses.

**Pick: test/gemma12b/A-minimal-8k/chat/filtered-title-noverify.** No eligible config reaches 290 TEST matches; test/gemma12b/A-minimal-8k/chat/filtered-title-noverify has the highest TEST recall (23/365) among eligible configs with TEST precision >= 15%.

**Because TEST was used to choose, the pick's TEST result is an optimistic estimate, not a held-out result.** Its DEV result is shown beside it.

DEV result of the same config: 6/9 (66.7% / 5.2%)*, 40 LLM calls

For information only (superseded DEV-only rule of plan amendment 1): none.

Candidates (plan amendment 3): Every single-format cohort of every format (chat8192, schema8192, schema16384, chat-default, json-default) at every stage, every declared within-arm format pool, and every cross-arm pool are eligible pick candidates under the plan-amendment-1 rule.

TEST result of the pick (optimistic, used to choose): 23/26 (88.5% / 6.3%), full-record 0.034, 40 LLM calls

TEST check against Opus (Rdb54680 290/1002 (precision 28.9%, recall 79.5%)): the pick does not match Opus with 23 TEST matches (needs >= 290); its TEST precision is 88.5% against Opus 28.9%.

## Quality audit

Audit file @TMP@/first-audit.json (SHA-256 b110c2c165c4): 9 cohort verdicts, 4 defect(s).

- dev/gemma12b/TR-bootstrap-8k/chat-default-think: defect - false positive
- test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect - false positive
- test/gemma12b/TR-bootstrap-8k/chat-default-think: defect - false positive
- test/qwen/A-minimal-8k/schema8192: defect - made-up defect

Configs excluded from the pick by the audit (TEST and DEV): 32.
- test/qwen/A-minimal-8k/chat+schema8192/combined: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/qwen/A-minimal-8k/chat+schema8192/verified-self: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/qwen/A-minimal-8k/chat+schema8192/filtered-title: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/qwen/A-minimal-8k/chat+schema8192/filtered-title-noverify: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/combined: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive); test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/verified-self: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive); test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/filtered-title: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive); test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/filtered-title-noverify: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive); test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/verified-qwen: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive); test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/filtered-title-qv: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive); test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/qwen/A-minimal-8k/schema8192/combined: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/qwen/A-minimal-8k/schema8192/verified-self: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/qwen/A-minimal-8k/schema8192/filtered-title: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/qwen/A-minimal-8k/schema8192/filtered-title-noverify: test/qwen/A-minimal-8k/schema8192: defect (made-up defect)
- test/gemma12b/TR-bootstrap-16k32k/chat-default-think/combined: test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-16k32k/chat-default-think/verified-self: test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-title: test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-title-noverify: test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-16k32k/chat-default-think/verified-qwen: test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-title-qv: test/gemma12b/TR-bootstrap-16k32k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k/chat-default-think/combined: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k/chat-default-think/verified-self: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title-noverify: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k/chat-default-think/verified-qwen: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title-qv: test/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- dev/gemma12b/TR-bootstrap-8k/chat-default-think/combined: dev/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- dev/gemma12b/TR-bootstrap-8k/chat-default-think/verified-self: dev/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- dev/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title: dev/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- dev/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title-noverify: dev/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- dev/gemma12b/TR-bootstrap-8k/chat-default-think/verified-qwen: dev/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)
- dev/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title-qv: dev/gemma12b/TR-bootstrap-8k/chat-default-think: defect (false positive)

## Cheapest configs by DEV recall level

For each DEV recall level: the eligible config (DEV precision >= 15%) with the fewest LLM calls on DEV, and the same config on TEST. TEST is shown for information and never used to choose.

| DEV recall at least | Config | DEV matches/predicted | DEV precision | DEV recall | DEV LLM calls | TEST matches/predicted | TEST precision | TEST recall | TEST LLM calls |
|---|---|---|---|---|---|---|---|---|---|
| 50% | none | | | | | | | | |
| 55% | none | | | | | | | | |
| 60% | none | | | | | | | | |
| 65% | none | | | | | | | | |
| 70% | none | | | | | | | | |
| 75% | none | | | | | | | | |
| 80% | none | | | | | | | | |
| 85% | none | | | | | | | | |
| 90% | none | | | | | | | | |
| reference | Opus Rdb54680 (paid API) | 100/521 | 19.2% | 87.0% | 270 | 290/1002 | 28.9% | 79.5% | 494 |

## Reasoning off vs default-on (same model, arm, format and stage)

Off = thinking disabled, temperature 0. Default-on = the model's own thinking and shipped sampling settings. The Qwen-verified stage uses the common Qwen verifier (thinking off) for both models. Output tokens include reasoning tokens. Compute is reported only; it is not used to choose.

| Model | Arm | Formats (off / on) | Stage | DEV off | DEV on | TEST off | TEST on | DEV LLM calls off / on | DEV output tokens off / on | DEV reasoning tokens on | DEV generation minutes off / on |
|---|---|---|---|---|---|---|---|---|---|---|---|
| qwen | A-minimal-8k | chat-default / chat-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | chat-default / chat-default-think | filtered-title | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | chat-default / chat-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | json-default / json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | json-default / json-default-think | filtered-title | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | json-default / json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | chat-default+json-default / chat-default-think+json-default-think | combined | missing | missing | missing | missing |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | chat-default+json-default / chat-default-think+json-default-think | filtered-title | missing | missing | missing | missing |  /  |  /  |  |  /  |
| qwen | A-minimal-8k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-noverify | missing | missing | missing | missing |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | chat-default / chat-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | chat-default / chat-default-think | filtered-title | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | chat-default / chat-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | json-default / json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | json-default / json-default-think | filtered-title | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | json-default / json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default / chat-default-think+json-default-think | combined | not run | not run | missing | missing |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title | not run | not run | missing | missing |  /  |  /  |  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-noverify | not run | not run | missing | missing |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | chat-default / chat-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | chat-default / chat-default-think | filtered-title | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | chat-default / chat-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | json-default / json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | json-default / json-default-think | filtered-title | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | json-default / json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default / chat-default-think+json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title | not run | not run | not run | not run |  /  |  /  |  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | chat-default / chat-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | chat-default / chat-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | chat-default / chat-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | json-default / json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | json-default / json-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | json-default / json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default / chat-default-think+json-default-think | combined | missing | missing | missing | missing |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-qv | missing | missing | missing | missing |  /  |  /  |  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-noverify | missing | missing | missing | missing |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | chat-default / chat-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | chat-default / chat-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | chat-default / chat-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | json-default / json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | json-default / json-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | json-default / json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default / chat-default-think+json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | chat-default / chat-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | chat-default / chat-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | chat-default / chat-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | json-default / json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | json-default / json-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | json-default / json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default / chat-default-think+json-default-think | combined | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-qv | not run | not run | not run | not run |  /  |  /  |  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default / chat-default-think+json-default-think | filtered-title-noverify | not run | not run | not run | not run |  /  |  /  |  |  /  |

## Same setup, different model

Cells: matches/predicted (precision / recall); * = not eligible under the failure policy. For Qwen, the rows 'checked by Qwen' show Qwen's own verifier, which is the common Qwen verifier.

| Arm | Passes | Stage | Qwen DEV | Gemma DEV | Qwen TEST | Gemma TEST |
|---|---|---|---|---|---|---|
| A-minimal-8k | chat | combined | 12/15 (80.0% / 10.4%)* | 7/10 (70.0% / 6.1%)* | 27/30 (90.0% / 7.4%)* | 19/22 (86.4% / 5.2%) |
| A-minimal-8k | chat | verified-self | 6/9 (66.7% / 5.2%)* | 6/9 (66.7% / 5.2%)* | 4/7 (57.1% / 1.1%)* | 4/7 (57.1% / 1.1%) |
| A-minimal-8k | chat | filtered-title | 12/15 (80.0% / 10.4%)* | 7/10 (70.0% / 6.1%)* | 27/30 (90.0% / 7.4%)* | 19/22 (86.4% / 5.2%) |
| A-minimal-8k | chat | filtered-ordinary | missing | missing | missing | missing |
| A-minimal-8k | chat | filtered-title-noverify | 7/10 (70.0% / 6.1%)* | 6/9 (66.7% / 5.2%)* | 23/26 (88.5% / 6.3%)* | 23/26 (88.5% / 6.3%) |
| A-minimal-8k | chat | filtered-ordinary-noverify | missing | missing | missing | missing |
| A-minimal-8k | chat | verified-qwen | 6/9 (66.7% / 5.2%)* | 7/10 (70.0% / 6.1%)* | 4/7 (57.1% / 1.1%)* | 19/22 (86.4% / 5.2%)* |
| A-minimal-8k | chat | filtered-title-qv | 12/15 (80.0% / 10.4%)* | 7/10 (70.0% / 6.1%)* | 27/30 (90.0% / 7.4%)* | 19/22 (86.4% / 5.2%)* |
| A-minimal-8k | chat | filtered-ordinary-qv | missing | missing | missing | missing |
| A-minimal-8k | chat+schema8192 | combined | missing | missing | 46/52 (88.5% / 12.6%)* | missing |
| A-minimal-8k | chat+schema8192 | verified-self | missing | missing | 23/29 (79.3% / 6.3%)* | missing |
| A-minimal-8k | chat+schema8192 | filtered-title | missing | missing | 46/52 (88.5% / 12.6%)* | missing |
| A-minimal-8k | chat+schema8192 | filtered-ordinary | missing | missing | missing | missing |
| A-minimal-8k | chat+schema8192 | filtered-title-noverify | missing | missing | 27/33 (81.8% / 7.4%)* | missing |
| A-minimal-8k | chat+schema8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| A-minimal-8k | chat+schema8192 | verified-qwen | missing | missing | 23/29 (79.3% / 6.3%)* | missing |
| A-minimal-8k | chat+schema8192 | filtered-title-qv | missing | missing | 46/52 (88.5% / 12.6%)* | missing |
| A-minimal-8k | chat+schema8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| A-minimal-8k | all3 | combined | missing | missing | missing | missing |
| A-minimal-8k | all3 | verified-self | missing | missing | missing | missing |
| A-minimal-8k | all3 | filtered-title | missing | missing | missing | missing |
| A-minimal-8k | all3 | filtered-ordinary | missing | missing | missing | missing |
| A-minimal-8k | all3 | filtered-title-noverify | missing | missing | missing | missing |
| A-minimal-8k | all3 | filtered-ordinary-noverify | missing | missing | missing | missing |
| A-minimal-8k | all3 | verified-qwen | missing | missing | missing | missing |
| A-minimal-8k | all3 | filtered-title-qv | missing | missing | missing | missing |
| A-minimal-8k | all3 | filtered-ordinary-qv | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | combined | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | verified-self | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | filtered-title | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | filtered-ordinary | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | filtered-title-noverify | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | verified-qwen | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | filtered-title-qv | missing | missing | missing | missing |
| A-minimal-8k | chat-default+json-default | filtered-ordinary-qv | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | combined | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | verified-self | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | filtered-title | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | filtered-title-noverify | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | verified-qwen | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | filtered-title-qv | missing | missing | missing | missing |
| A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| B-minimal-16k32k | chat | combined | not run | not run | 27/30 (90.0% / 7.4%)* | not run |
| B-minimal-16k32k | chat | verified-self | not run | not run | 23/26 (88.5% / 6.3%)* | not run |
| B-minimal-16k32k | chat | filtered-title | not run | not run | 27/30 (90.0% / 7.4%)* | not run |
| B-minimal-16k32k | chat | filtered-ordinary | not run | not run | missing | not run |
| B-minimal-16k32k | chat | filtered-title-noverify | not run | not run | 19/22 (86.4% / 5.2%)* | not run |
| B-minimal-16k32k | chat | filtered-ordinary-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | chat | verified-qwen | not run | not run | 23/26 (88.5% / 6.3%)* | not run |
| B-minimal-16k32k | chat | filtered-title-qv | not run | not run | 27/30 (90.0% / 7.4%)* | not run |
| B-minimal-16k32k | chat | filtered-ordinary-qv | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | combined | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | verified-self | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | filtered-title | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | filtered-ordinary | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | filtered-title-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | filtered-ordinary-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | verified-qwen | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | filtered-title-qv | not run | not run | missing | not run |
| B-minimal-16k32k | chat+schema8192 | filtered-ordinary-qv | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | combined | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | verified-self | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | filtered-title | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | filtered-ordinary | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | filtered-title-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | filtered-ordinary-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | verified-qwen | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | filtered-title-qv | not run | not run | missing | not run |
| B-minimal-16k32k | all3 | filtered-ordinary-qv | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | combined | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | verified-self | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | filtered-title | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | filtered-ordinary | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | filtered-title-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | filtered-ordinary-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | verified-qwen | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | filtered-title-qv | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default+json-default | filtered-ordinary-qv | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | combined | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | verified-self | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | filtered-title | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | filtered-title-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | verified-qwen | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | filtered-title-qv | not run | not run | missing | not run |
| B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | not run | not run | missing | not run |
| C-gepa-16k32k | chat | combined | not run | not run | not run | not run |
| C-gepa-16k32k | chat | verified-self | not run | not run | not run | not run |
| C-gepa-16k32k | chat | filtered-title | not run | not run | not run | not run |
| C-gepa-16k32k | chat | filtered-ordinary | not run | not run | not run | not run |
| C-gepa-16k32k | chat | filtered-title-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat | filtered-ordinary-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat | verified-qwen | not run | not run | not run | not run |
| C-gepa-16k32k | chat | filtered-title-qv | not run | not run | not run | not run |
| C-gepa-16k32k | chat | filtered-ordinary-qv | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | combined | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | verified-self | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | filtered-title | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | filtered-ordinary | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | filtered-title-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | filtered-ordinary-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | verified-qwen | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | filtered-title-qv | not run | not run | not run | not run |
| C-gepa-16k32k | chat+schema8192 | filtered-ordinary-qv | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | combined | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | verified-self | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | filtered-title | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | filtered-ordinary | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | filtered-title-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | filtered-ordinary-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | verified-qwen | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | filtered-title-qv | not run | not run | not run | not run |
| C-gepa-16k32k | all3 | filtered-ordinary-qv | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | combined | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | verified-self | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | filtered-title | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | filtered-ordinary | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | filtered-title-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | filtered-ordinary-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | verified-qwen | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | filtered-title-qv | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default+json-default | filtered-ordinary-qv | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | combined | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | verified-self | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | filtered-title | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | filtered-title-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | verified-qwen | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | filtered-title-qv | not run | not run | not run | not run |
| C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | not run | not run | not run | not run |
| AB-minimal-8k16k32k | chat8192 | combined | missing | missing | 27/33 (81.8% / 7.4%)* | missing |
| AB-minimal-8k16k32k | chat8192 | verified-self | missing | missing | 27/33 (81.8% / 7.4%)* | missing |
| AB-minimal-8k16k32k | chat8192 | filtered-title | missing | missing | 27/33 (81.8% / 7.4%)* | missing |
| AB-minimal-8k16k32k | chat8192 | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat8192 | filtered-title-noverify | missing | missing | 42/48 (87.5% / 11.5%)* | missing |
| AB-minimal-8k16k32k | chat8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat8192 | verified-qwen | missing | missing | 27/33 (81.8% / 7.4%)* | missing |
| AB-minimal-8k16k32k | chat8192 | filtered-title-qv | missing | missing | 27/33 (81.8% / 7.4%)* | missing |
| AB-minimal-8k16k32k | chat8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | schema16384 | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | json-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | all3 | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | combined | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | verified-self | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | verified-qwen | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title-qv | missing | missing | missing | missing |
| AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | all3 | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | combined | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | verified-self | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | verified-qwen | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title-qv | missing | missing | missing | missing |
| AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | chat8192 | combined | missing | missing | missing | missing |
| ABC-all | chat8192 | verified-self | missing | missing | missing | missing |
| ABC-all | chat8192 | filtered-title | missing | missing | missing | missing |
| ABC-all | chat8192 | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | chat8192 | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | chat8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | chat8192 | verified-qwen | missing | missing | missing | missing |
| ABC-all | chat8192 | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | chat8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | schema8192 | combined | missing | missing | missing | missing |
| ABC-all | schema8192 | verified-self | missing | missing | missing | missing |
| ABC-all | schema8192 | filtered-title | missing | missing | missing | missing |
| ABC-all | schema8192 | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | schema8192 | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | schema8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | schema8192 | verified-qwen | missing | missing | missing | missing |
| ABC-all | schema8192 | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | schema8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | schema16384 | combined | missing | missing | missing | missing |
| ABC-all | schema16384 | verified-self | missing | missing | missing | missing |
| ABC-all | schema16384 | filtered-title | missing | missing | missing | missing |
| ABC-all | schema16384 | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | schema16384 | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | schema16384 | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | schema16384 | verified-qwen | missing | missing | missing | missing |
| ABC-all | schema16384 | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | schema16384 | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | chat-default | combined | missing | missing | missing | missing |
| ABC-all | chat-default | verified-self | missing | missing | missing | missing |
| ABC-all | chat-default | filtered-title | missing | missing | missing | missing |
| ABC-all | chat-default | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | chat-default | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | chat-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | chat-default | verified-qwen | missing | missing | missing | missing |
| ABC-all | chat-default | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | chat-default | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | json-default | combined | missing | missing | missing | missing |
| ABC-all | json-default | verified-self | missing | missing | missing | missing |
| ABC-all | json-default | filtered-title | missing | missing | missing | missing |
| ABC-all | json-default | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | json-default | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | json-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | json-default | verified-qwen | missing | missing | missing | missing |
| ABC-all | json-default | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | json-default | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | chat-default-think | combined | missing | missing | missing | missing |
| ABC-all | chat-default-think | verified-self | missing | missing | missing | missing |
| ABC-all | chat-default-think | filtered-title | missing | missing | missing | missing |
| ABC-all | chat-default-think | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | chat-default-think | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | chat-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | chat-default-think | verified-qwen | missing | missing | missing | missing |
| ABC-all | chat-default-think | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | chat-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | json-default-think | combined | missing | missing | missing | missing |
| ABC-all | json-default-think | verified-self | missing | missing | missing | missing |
| ABC-all | json-default-think | filtered-title | missing | missing | missing | missing |
| ABC-all | json-default-think | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | json-default-think | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | json-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | json-default-think | verified-qwen | missing | missing | missing | missing |
| ABC-all | json-default-think | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | json-default-think | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | combined | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | verified-self | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | filtered-title | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | verified-qwen | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | chat+schema8192 | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | all3 | combined | missing | missing | missing | missing |
| ABC-all | all3 | verified-self | missing | missing | missing | missing |
| ABC-all | all3 | filtered-title | missing | missing | missing | missing |
| ABC-all | all3 | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | all3 | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | all3 | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | all3 | verified-qwen | missing | missing | missing | missing |
| ABC-all | all3 | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | all3 | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | combined | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | verified-self | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | filtered-title | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | verified-qwen | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | chat-default+json-default | filtered-ordinary-qv | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | combined | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | verified-self | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | filtered-title | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | filtered-ordinary | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | filtered-title-noverify | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | filtered-ordinary-noverify | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | verified-qwen | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | filtered-title-qv | missing | missing | missing | missing |
| ABC-all | chat-default-think+json-default-think | filtered-ordinary-qv | missing | missing | missing | missing |

## Every config (DEV and TEST)

| Model | Arm | Passes | Stage | DEV | DEV F1 | DEV full-record | TEST | TEST F1 | TEST full-record | Model calls (DEV / TEST) | Output tokens (DEV / TEST) | Reasoning tokens (DEV / TEST) | Generation minutes (DEV / TEST) | Eligible (DEV / TEST) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| qwen | A-minimal-8k | chat | combined | 12/15 (80.0% / 10.4%)* | 0.185 | 0.093 | 27/30 (90.0% / 7.4%)* | 0.137 | 0.065 | 40 / 40 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / no |
| qwen | A-minimal-8k | chat | verified-self | 6/9 (66.7% / 5.2%)* | 0.097 | 0.046 | 4/7 (57.1% / 1.1%)* | 0.022 | 0.036 | 60 / 60 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / no |
| qwen | A-minimal-8k | chat | filtered-title | 12/15 (80.0% / 10.4%)* | 0.185 | 0.093 | 27/30 (90.0% / 7.4%)* | 0.137 | 0.065 | 60 / 60 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / no |
| qwen | A-minimal-8k | chat | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat | filtered-title-noverify | 7/10 (70.0% / 6.1%)* | 0.112 | 0.046 | 23/26 (88.5% / 6.3%)* | 0.118 | 0.034 | 40 / 40 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / no |
| qwen | A-minimal-8k | chat | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat+schema8192 | combined | missing |  |  | 46/52 (88.5% / 12.6%)* | 0.221 | 0.091 |  / 80 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | A-minimal-8k | chat+schema8192 | verified-self | missing |  |  | 23/29 (79.3% / 6.3%)* | 0.117 | 0.064 |  / 120 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | A-minimal-8k | chat+schema8192 | filtered-title | missing |  |  | 46/52 (88.5% / 12.6%)* | 0.221 | 0.091 |  / 120 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | A-minimal-8k | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat+schema8192 | filtered-title-noverify | missing |  |  | 27/33 (81.8% / 7.4%)* | 0.136 | 0.061 |  / 80 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | A-minimal-8k | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat | combined | not run |  |  | 27/30 (90.0% / 7.4%)* | 0.137 | 0.065 |  / 40 |  / 150 |  / 0 |  / 0.1 |  / no |
| qwen | B-minimal-16k32k | chat | verified-self | not run |  |  | 23/26 (88.5% / 6.3%)* | 0.118 | 0.034 |  / 60 |  / 150 |  / 0 |  / 0.1 |  / no |
| qwen | B-minimal-16k32k | chat | filtered-title | not run |  |  | 27/30 (90.0% / 7.4%)* | 0.137 | 0.065 |  / 60 |  / 150 |  / 0 |  / 0.1 |  / no |
| qwen | B-minimal-16k32k | chat | filtered-ordinary | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat | filtered-title-noverify | not run |  |  | 19/22 (86.4% / 5.2%)* | 0.098 | 0.041 |  / 40 |  / 150 |  / 0 |  / 0.1 |  / no |
| qwen | B-minimal-16k32k | chat | filtered-ordinary-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat | verified-qwen | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat | filtered-title-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat | filtered-ordinary-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | combined | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | verified-self | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | filtered-title | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | filtered-ordinary | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | filtered-title-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | filtered-ordinary-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | verified-qwen | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | filtered-title-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat+schema8192 | filtered-ordinary-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | combined | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | verified-self | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | filtered-title | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | filtered-ordinary | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | filtered-title-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | filtered-ordinary-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | verified-qwen | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | filtered-title-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | all3 | filtered-ordinary-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | combined | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | verified-self | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | filtered-title | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | filtered-ordinary | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | filtered-title-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | filtered-ordinary-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | verified-qwen | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | filtered-title-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default+json-default | filtered-ordinary-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | combined | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | verified-self | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | filtered-title | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | filtered-title-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | verified-qwen | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | filtered-title-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat+schema8192 | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | all3 | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default+json-default | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat8192 | combined | missing |  |  | 27/33 (81.8% / 7.4%)* | 0.136 | 0.061 |  / 80 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | AB-minimal-8k16k32k | chat8192 | verified-self | missing |  |  | 27/33 (81.8% / 7.4%)* | 0.136 | 0.061 |  / 120 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | AB-minimal-8k16k32k | chat8192 | filtered-title | missing |  |  | 27/33 (81.8% / 7.4%)* | 0.136 | 0.061 |  / 120 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | AB-minimal-8k16k32k | chat8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat8192 | filtered-title-noverify | missing |  |  | 42/48 (87.5% / 11.5%)* | 0.203 | 0.068 |  / 80 |  / 300 |  / 0 |  / 0.1 |  / no |
| qwen | AB-minimal-8k16k32k | chat8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | schema16384 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | schema16384 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| qwen | ABC-all | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat | combined | 7/10 (70.0% / 6.1%)* | 0.112 | 0.057 | 19/22 (86.4% / 5.2%) | 0.098 | 0.041 | 40 / 40 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / yes |
| gemma12b | A-minimal-8k | chat | verified-self | 6/9 (66.7% / 5.2%)* | 0.097 | 0.057 | 4/7 (57.1% / 1.1%) | 0.022 | 0.036 | 60 / 60 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / yes |
| gemma12b | A-minimal-8k | chat | filtered-title | 7/10 (70.0% / 6.1%)* | 0.112 | 0.057 | 19/22 (86.4% / 5.2%) | 0.098 | 0.041 | 60 / 60 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / yes |
| gemma12b | A-minimal-8k | chat | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat | filtered-title-noverify | 6/9 (66.7% / 5.2%)* | 0.097 | 0.046 | 23/26 (88.5% / 6.3%) | 0.118 | 0.034 | 40 / 40 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / yes |
| gemma12b | A-minimal-8k | chat | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat | verified-qwen | 7/10 (70.0% / 6.1%)* | 0.112 | 0.057 | 19/22 (86.4% / 5.2%)* | 0.098 | 0.041 | 50 / 50 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / no |
| gemma12b | A-minimal-8k | chat | filtered-title-qv | 7/10 (70.0% / 6.1%)* | 0.112 | 0.046 | 19/22 (86.4% / 5.2%)* | 0.098 | 0.041 | 50 / 50 | 150 / 150 | 0 / 0 | 0.1 / 0.1 | no / no |
| gemma12b | A-minimal-8k | chat | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | A-minimal-8k | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat+schema8192 | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | all3 | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default+json-default | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | B-minimal-16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat+schema8192 | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | all3 | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default+json-default | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | combined | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | verified-self | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | filtered-title | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | filtered-title-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | verified-qwen | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | filtered-title-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | C-gepa-16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | not run |  |  | not run |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | schema16384 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AB-minimal-8k16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | schema16384 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | AC-minimal8k-gepa16k32k | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | schema16384 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat+schema8192 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | all3 | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default+json-default | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | combined | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | verified-self | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | filtered-title | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | filtered-ordinary | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | filtered-title-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | filtered-ordinary-noverify | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | verified-qwen | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | filtered-title-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | ABC-all | chat-default-think+json-default-think | filtered-ordinary-qv | missing |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | combined | not run |  |  | 46/52 (88.5% / 12.6%)* | 0.221 | 0.091 |  / 80 |  / 300 |  / 0 |  / 0.1 |  / no |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | verified-self | not run |  |  | 23/29 (79.3% / 6.3%)* | 0.117 | 0.064 |  / 120 |  / 300 |  / 0 |  / 0.1 |  / no |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | filtered-title | not run |  |  | 46/52 (88.5% / 12.6%)* | 0.221 | 0.091 |  / 120 |  / 300 |  / 0 |  / 0.1 |  / no |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | filtered-ordinary | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | filtered-title-noverify | not run |  |  | 27/33 (81.8% / 7.4%)* | 0.136 | 0.061 |  / 80 |  / 300 |  / 0 |  / 0.1 |  / no |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | filtered-ordinary-noverify | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | verified-qwen | not run |  |  | 46/52 (88.5% / 12.6%)* | 0.221 | 0.091 |  / 100 |  / 300 |  / 0 |  / 0.1 |  / no |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | filtered-title-qv | not run |  |  | 42/48 (87.5% / 11.5%)* | 0.203 | 0.068 |  / 100 |  / 300 |  / 0 |  / 0.1 |  / no |
| gemma12b | TR-bootstrap-8k+16k32k | chat-default-think | filtered-ordinary-qv | not run |  |  | missing |  |  |  /  |  /  |  /  |  /  |  /  |

## Single-format cohorts

| Split | Model | Arm | Format | Stage | Result | Model calls | Eligible |
|---|---|---|---|---|---|---|---|
| dev | qwen | A-minimal-8k | chat8192 | combined | 12/15 (80.0% / 10.4%)* | 40 | no |
| dev | qwen | A-minimal-8k | chat8192 | verified-self | 6/9 (66.7% / 5.2%)* | 60 | no |
| dev | qwen | A-minimal-8k | chat8192 | filtered-title | 12/15 (80.0% / 10.4%)* | 60 | no |
| dev | qwen | A-minimal-8k | chat8192 | filtered-title-noverify | 7/10 (70.0% / 6.1%)* | 40 | no |
| dev | gemma12b | A-minimal-8k | chat8192 | combined | 7/10 (70.0% / 6.1%)* | 40 | no |
| dev | gemma12b | A-minimal-8k | chat8192 | verified-self | 6/9 (66.7% / 5.2%)* | 60 | no |
| dev | gemma12b | A-minimal-8k | chat8192 | filtered-title | 7/10 (70.0% / 6.1%)* | 60 | no |
| dev | gemma12b | A-minimal-8k | chat8192 | filtered-title-noverify | 6/9 (66.7% / 5.2%)* | 40 | no |
| dev | gemma12b | A-minimal-8k | chat8192 | verified-qwen | 7/10 (70.0% / 6.1%)* | 50 | no |
| dev | gemma12b | A-minimal-8k | chat8192 | filtered-title-qv | 7/10 (70.0% / 6.1%)* | 50 | no |
| test | qwen | A-minimal-8k | chat8192 | combined | 27/30 (90.0% / 7.4%)* | 40 | no |
| test | qwen | A-minimal-8k | schema8192 | combined | 19/22 (86.4% / 5.2%)* | 40 | no |
| test | qwen | A-minimal-8k | chat8192 | verified-self | 4/7 (57.1% / 1.1%)* | 60 | no |
| test | qwen | A-minimal-8k | schema8192 | verified-self | 19/22 (86.4% / 5.2%)* | 60 | no |
| test | qwen | A-minimal-8k | chat8192 | filtered-title | 27/30 (90.0% / 7.4%)* | 60 | no |
| test | qwen | A-minimal-8k | schema8192 | filtered-title | 19/22 (86.4% / 5.2%)* | 60 | no |
| test | qwen | A-minimal-8k | chat8192 | filtered-title-noverify | 23/26 (88.5% / 6.3%)* | 40 | no |
| test | qwen | A-minimal-8k | schema8192 | filtered-title-noverify | 4/7 (57.1% / 1.1%)* | 40 | no |
| test | qwen | B-minimal-16k32k | chat8192 | combined | 27/30 (90.0% / 7.4%)* | 40 | no |
| test | qwen | B-minimal-16k32k | chat8192 | verified-self | 23/26 (88.5% / 6.3%)* | 60 | no |
| test | qwen | B-minimal-16k32k | chat8192 | filtered-title | 27/30 (90.0% / 7.4%)* | 60 | no |
| test | qwen | B-minimal-16k32k | chat8192 | filtered-title-noverify | 19/22 (86.4% / 5.2%)* | 40 | no |
| test | gemma12b | A-minimal-8k | chat8192 | combined | 19/22 (86.4% / 5.2%) | 40 | yes |
| test | gemma12b | A-minimal-8k | chat8192 | verified-self | 4/7 (57.1% / 1.1%) | 60 | yes |
| test | gemma12b | A-minimal-8k | chat8192 | filtered-title | 19/22 (86.4% / 5.2%) | 60 | yes |
| test | gemma12b | A-minimal-8k | chat8192 | filtered-title-noverify | 23/26 (88.5% / 6.3%) | 40 | yes |
| test | gemma12b | A-minimal-8k | chat8192 | verified-qwen | 19/22 (86.4% / 5.2%)* | 50 | no |
| test | gemma12b | A-minimal-8k | chat8192 | filtered-title-qv | 19/22 (86.4% / 5.2%)* | 50 | no |
| dev | gemma12b | TR-bootstrap-8k | chat-default-think | combined | 12/15 (80.0% / 10.4%)* | 40 | no |
| dev | gemma12b | TR-bootstrap-8k | chat-default-think | verified-self | 6/9 (66.7% / 5.2%)* | 60 | no |
| dev | gemma12b | TR-bootstrap-8k | chat-default-think | filtered-title | 12/15 (80.0% / 10.4%)* | 60 | no |
| dev | gemma12b | TR-bootstrap-8k | chat-default-think | filtered-title-noverify | 6/9 (66.7% / 5.2%)* | 40 | no |
| dev | gemma12b | TR-bootstrap-8k | chat-default-think | verified-qwen | 12/15 (80.0% / 10.4%)* | 50 | no |
| dev | gemma12b | TR-bootstrap-8k | chat-default-think | filtered-title-qv | 7/10 (70.0% / 6.1%)* | 50 | no |
| test | gemma12b | TR-bootstrap-16k32k | chat-default-think | combined | 19/22 (86.4% / 5.2%)* | 40 | no |
| test | gemma12b | TR-bootstrap-16k32k | chat-default-think | verified-self | 19/22 (86.4% / 5.2%)* | 60 | no |
| test | gemma12b | TR-bootstrap-16k32k | chat-default-think | filtered-title | 19/22 (86.4% / 5.2%)* | 60 | no |
| test | gemma12b | TR-bootstrap-16k32k | chat-default-think | filtered-title-noverify | 4/7 (57.1% / 1.1%)* | 40 | no |
| test | gemma12b | TR-bootstrap-16k32k | chat-default-think | verified-qwen | 19/22 (86.4% / 5.2%)* | 50 | no |
| test | gemma12b | TR-bootstrap-16k32k | chat-default-think | filtered-title-qv | 23/26 (88.5% / 6.3%)* | 50 | no |
| test | gemma12b | TR-bootstrap-8k | chat-default-think | combined | 27/30 (90.0% / 7.4%)* | 40 | no |
| test | gemma12b | TR-bootstrap-8k | chat-default-think | verified-self | 4/7 (57.1% / 1.1%)* | 60 | no |
| test | gemma12b | TR-bootstrap-8k | chat-default-think | filtered-title | 27/30 (90.0% / 7.4%)* | 60 | no |
| test | gemma12b | TR-bootstrap-8k | chat-default-think | filtered-title-noverify | 23/26 (88.5% / 6.3%)* | 40 | no |
| test | gemma12b | TR-bootstrap-8k | chat-default-think | verified-qwen | 27/30 (90.0% / 7.4%)* | 50 | no |
| test | gemma12b | TR-bootstrap-8k | chat-default-think | filtered-title-qv | 19/22 (86.4% / 5.2%)* | 50 | no |

## Run-to-run spread

First TEST generation of the same recipe (QWEN-POOL3): 3/7. This grid's fresh generation is not available.

## Why configs are not eligible

- dev/qwen/A-minimal-8k/chat/combined: dev/qwen/A-minimal-8k/chat8192/combined: 18/21 papers without output (incl. all windows failed)
- dev/qwen/A-minimal-8k/chat/verified-self: dev/qwen/A-minimal-8k/chat8192/verified-self: 18/21 papers without output (incl. all windows failed)
- dev/qwen/A-minimal-8k/chat/filtered-title: dev/qwen/A-minimal-8k/chat8192/filtered-title: 18/21 papers without output (incl. all windows failed)
- dev/qwen/A-minimal-8k/chat/filtered-title-noverify: dev/qwen/A-minimal-8k/chat8192/filtered-title-noverify: 18/21 papers without output (incl. all windows failed)
- dev/gemma12b/A-minimal-8k/chat/combined: dev/gemma12b/A-minimal-8k/chat8192/combined: 18/21 papers without output (incl. all windows failed)
- dev/gemma12b/A-minimal-8k/chat/verified-self: dev/gemma12b/A-minimal-8k/chat8192/verified-self: 18/21 papers without output (incl. all windows failed)
- dev/gemma12b/A-minimal-8k/chat/filtered-title: dev/gemma12b/A-minimal-8k/chat8192/filtered-title: 18/21 papers without output (incl. all windows failed)
- dev/gemma12b/A-minimal-8k/chat/filtered-title-noverify: dev/gemma12b/A-minimal-8k/chat8192/filtered-title-noverify: 18/21 papers without output (incl. all windows failed)
- dev/gemma12b/A-minimal-8k/chat/verified-qwen: dev/gemma12b/A-minimal-8k/chat8192/verified-qwen: 18/21 papers without output (incl. all windows failed)
- dev/gemma12b/A-minimal-8k/chat/filtered-title-qv: dev/gemma12b/A-minimal-8k/chat8192/filtered-title-qv: 18/21 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat/combined: test/qwen/A-minimal-8k/chat8192/combined: paper outside split: not-a-test-paper; test/qwen/A-minimal-8k/chat8192/combined: 26/29 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat+schema8192/combined: test/qwen/A-minimal-8k/chat8192/combined: paper outside split: not-a-test-paper; test/qwen/A-minimal-8k/chat8192/combined: 26/29 papers without output (incl. all windows failed); test/qwen/A-minimal-8k/schema8192/combined: 27/29 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat/verified-self: test/qwen/A-minimal-8k/chat8192/verified-self: 26/29 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat+schema8192/verified-self: test/qwen/A-minimal-8k/chat8192/verified-self: 26/29 papers without output (incl. all windows failed); test/qwen/A-minimal-8k/schema8192/verified-self: 27/29 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat/filtered-title: test/qwen/A-minimal-8k/chat8192/filtered-title: 26/29 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat+schema8192/filtered-title: test/qwen/A-minimal-8k/chat8192/filtered-title: 26/29 papers without output (incl. all windows failed); test/qwen/A-minimal-8k/schema8192/filtered-title: 27/29 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat/filtered-title-noverify: test/qwen/A-minimal-8k/chat8192/filtered-title-noverify: 26/29 papers without output (incl. all windows failed)
- test/qwen/A-minimal-8k/chat+schema8192/filtered-title-noverify: test/qwen/A-minimal-8k/chat8192/filtered-title-noverify: 26/29 papers without output (incl. all windows failed); test/qwen/A-minimal-8k/schema8192/filtered-title-noverify: 27/29 papers without output (incl. all windows failed)
- test/qwen/B-minimal-16k32k/chat/combined: test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/combined: 26/29 papers without output (incl. all windows failed)
- test/qwen/B-minimal-16k32k/chat/verified-self: test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/verified-self: 26/29 papers without output (incl. all windows failed)
- test/qwen/B-minimal-16k32k/chat/filtered-title: test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/filtered-title: 26/29 papers without output (incl. all windows failed)
- test/qwen/B-minimal-16k32k/chat/filtered-title-noverify: test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/filtered-title-noverify: 26/29 papers without output (incl. all windows failed)
- test/qwen/AB-minimal-8k16k32k/chat8192/combined: test/qwen/A-minimal-8k/chat8192/combined: paper outside split: not-a-test-paper; test/qwen/A-minimal-8k/chat8192/combined: 26/29 papers without output (incl. all windows failed); test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/combined: 26/29 papers without output (incl. all windows failed)
- test/qwen/AB-minimal-8k16k32k/chat8192/verified-self: test/qwen/A-minimal-8k/chat8192/verified-self: 26/29 papers without output (incl. all windows failed); test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/verified-self: 26/29 papers without output (incl. all windows failed)
- test/qwen/AB-minimal-8k16k32k/chat8192/filtered-title: test/qwen/A-minimal-8k/chat8192/filtered-title: 26/29 papers without output (incl. all windows failed); test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/filtered-title: 26/29 papers without output (incl. all windows failed)
- test/qwen/AB-minimal-8k16k32k/chat8192/filtered-title-noverify: test/qwen/A-minimal-8k/chat8192/filtered-title-noverify: 26/29 papers without output (incl. all windows failed); test/qwen/B-minimal-16k32k/chat8192: status.complete is not true; test/qwen/B-minimal-16k32k/chat8192/filtered-title-noverify: 26/29 papers without output (incl. all windows failed)
- test/gemma12b/A-minimal-8k/chat/verified-qwen: test/gemma12b/A-minimal-8k/chat8192: audit eligible_qv=false (failed windows None, failed batches None, papers with output None)
- test/gemma12b/A-minimal-8k/chat/filtered-title-qv: test/gemma12b/A-minimal-8k/chat8192: audit eligible_qv=false (failed windows None, failed batches None, papers with output None)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/combined: test/gemma12b/TR-bootstrap-8k/chat-default-think/combined: 26/29 papers without output (incl. all windows failed); test/gemma12b/TR-bootstrap-16k32k/chat-default-think/combined: 26/29 papers without output (incl. all windows failed)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/verified-self: test/gemma12b/TR-bootstrap-8k/chat-default-think/verified-self: 26/29 papers without output (incl. all windows failed); test/gemma12b/TR-bootstrap-16k32k/chat-default-think/verified-self: 26/29 papers without output (incl. all windows failed)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/filtered-title: test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title: 26/29 papers without output (incl. all windows failed); test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-title: 26/29 papers without output (incl. all windows failed)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/filtered-title-noverify: test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title-noverify: 26/29 papers without output (incl. all windows failed); test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-title-noverify: 26/29 papers without output (incl. all windows failed)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/verified-qwen: test/gemma12b/TR-bootstrap-8k/chat-default-think/verified-qwen: 26/29 papers without output (incl. all windows failed); test/gemma12b/TR-bootstrap-16k32k/chat-default-think/verified-qwen: 26/29 papers without output (incl. all windows failed)
- test/gemma12b/TR-bootstrap-8k+16k32k/chat-default-think/filtered-title-qv: test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-title-qv: 26/29 papers without output (incl. all windows failed); test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-title-qv: 26/29 papers without output (incl. all windows failed)

Trained-program cohorts not (yet) present (45): dev/qwen/TR-bootstrap-8k/chat-default-think, dev/qwen/TR-bootstrap-8k/json-default-think, dev/qwen/TR-bootstrap-16k32k/chat-default-think, dev/qwen/TR-bootstrap-16k32k/json-default-think, dev/qwen/TR-gepa-8k/chat-default-think, dev/qwen/TR-gepa-8k/json-default-think, dev/qwen/TR-gepa-16k32k/chat-default-think, dev/qwen/TR-gepa-16k32k/json-default-think, dev/qwen/TR-mipro-8k/chat-default-think, dev/qwen/TR-mipro-8k/json-default-think, dev/qwen/TR-mipro-16k32k/chat-default-think, dev/qwen/TR-mipro-16k32k/json-default-think, dev/gemma12b/TR-bootstrap-8k/json-default-think, dev/gemma12b/TR-bootstrap-16k32k/chat-default-think, dev/gemma12b/TR-bootstrap-16k32k/json-default-think, dev/gemma12b/TR-gepa-8k/chat-default-think, dev/gemma12b/TR-gepa-8k/json-default-think, dev/gemma12b/TR-gepa-16k32k/chat-default-think, dev/gemma12b/TR-gepa-16k32k/json-default-think, dev/gemma12b/TR-mipro-8k/chat-default-think, dev/gemma12b/TR-mipro-8k/json-default-think, dev/gemma12b/TR-mipro-16k32k/chat-default-think, dev/gemma12b/TR-mipro-16k32k/json-default-think, test/qwen/TR-bootstrap-8k/chat-default-think, test/qwen/TR-bootstrap-8k/json-default-think, test/qwen/TR-bootstrap-16k32k/chat-default-think, test/qwen/TR-bootstrap-16k32k/json-default-think, test/qwen/TR-gepa-8k/chat-default-think, test/qwen/TR-gepa-8k/json-default-think, test/qwen/TR-gepa-16k32k/chat-default-think, test/qwen/TR-gepa-16k32k/json-default-think, test/qwen/TR-mipro-8k/chat-default-think, test/qwen/TR-mipro-8k/json-default-think, test/qwen/TR-mipro-16k32k/chat-default-think, test/qwen/TR-mipro-16k32k/json-default-think, test/gemma12b/TR-bootstrap-8k/json-default-think, test/gemma12b/TR-bootstrap-16k32k/json-default-think, test/gemma12b/TR-gepa-8k/chat-default-think, test/gemma12b/TR-gepa-8k/json-default-think, test/gemma12b/TR-gepa-16k32k/chat-default-think, test/gemma12b/TR-gepa-16k32k/json-default-think, test/gemma12b/TR-mipro-8k/chat-default-think, test/gemma12b/TR-mipro-8k/json-default-think, test/gemma12b/TR-mipro-16k32k/chat-default-think, test/gemma12b/TR-mipro-16k32k/json-default-think

Missing cohorts (78): dev/qwen/A-minimal-8k/schema8192, dev/qwen/A-minimal-8k/schema16384, dev/qwen/A-minimal-8k/chat-default, dev/qwen/A-minimal-8k/json-default, dev/qwen/A-minimal-8k/chat-default-think, dev/qwen/A-minimal-8k/json-default-think, dev/qwen/B-minimal-16k32k/chat8192, dev/qwen/B-minimal-16k32k/schema8192, dev/qwen/B-minimal-16k32k/schema16384, dev/qwen/B-minimal-16k32k/chat-default, dev/qwen/B-minimal-16k32k/json-default, dev/qwen/B-minimal-16k32k/chat-default-think, dev/qwen/B-minimal-16k32k/json-default-think, dev/qwen/C-gepa-16k32k/chat8192, dev/qwen/C-gepa-16k32k/schema8192, dev/qwen/C-gepa-16k32k/schema16384, dev/qwen/C-gepa-16k32k/chat-default, dev/qwen/C-gepa-16k32k/json-default, dev/qwen/C-gepa-16k32k/chat-default-think, dev/qwen/C-gepa-16k32k/json-default-think, dev/gemma12b/A-minimal-8k/schema8192, dev/gemma12b/A-minimal-8k/schema16384, dev/gemma12b/A-minimal-8k/chat-default, dev/gemma12b/A-minimal-8k/json-default, dev/gemma12b/A-minimal-8k/chat-default-think, dev/gemma12b/A-minimal-8k/json-default-think, dev/gemma12b/B-minimal-16k32k/chat8192, dev/gemma12b/B-minimal-16k32k/schema8192, dev/gemma12b/B-minimal-16k32k/schema16384, dev/gemma12b/B-minimal-16k32k/chat-default, dev/gemma12b/B-minimal-16k32k/json-default, dev/gemma12b/B-minimal-16k32k/chat-default-think, dev/gemma12b/B-minimal-16k32k/json-default-think, dev/gemma12b/C-gepa-16k32k/chat8192, dev/gemma12b/C-gepa-16k32k/schema8192, dev/gemma12b/C-gepa-16k32k/schema16384, dev/gemma12b/C-gepa-16k32k/chat-default, dev/gemma12b/C-gepa-16k32k/json-default, dev/gemma12b/C-gepa-16k32k/chat-default-think, dev/gemma12b/C-gepa-16k32k/json-default-think, test/qwen/A-minimal-8k/schema16384, test/qwen/A-minimal-8k/chat-default, test/qwen/A-minimal-8k/json-default, test/qwen/A-minimal-8k/chat-default-think, test/qwen/A-minimal-8k/json-default-think, test/qwen/B-minimal-16k32k/schema8192, test/qwen/B-minimal-16k32k/schema16384, test/qwen/B-minimal-16k32k/chat-default, test/qwen/B-minimal-16k32k/json-default, test/qwen/B-minimal-16k32k/chat-default-think, test/qwen/B-minimal-16k32k/json-default-think, test/qwen/C-gepa-16k32k/chat8192, test/qwen/C-gepa-16k32k/schema8192, test/qwen/C-gepa-16k32k/schema16384, test/qwen/C-gepa-16k32k/chat-default, test/qwen/C-gepa-16k32k/json-default, test/qwen/C-gepa-16k32k/chat-default-think, test/qwen/C-gepa-16k32k/json-default-think, test/gemma12b/A-minimal-8k/schema8192, test/gemma12b/A-minimal-8k/schema16384, test/gemma12b/A-minimal-8k/chat-default, test/gemma12b/A-minimal-8k/json-default, test/gemma12b/A-minimal-8k/chat-default-think, test/gemma12b/A-minimal-8k/json-default-think, test/gemma12b/B-minimal-16k32k/chat8192, test/gemma12b/B-minimal-16k32k/schema8192, test/gemma12b/B-minimal-16k32k/schema16384, test/gemma12b/B-minimal-16k32k/chat-default, test/gemma12b/B-minimal-16k32k/json-default, test/gemma12b/B-minimal-16k32k/chat-default-think, test/gemma12b/B-minimal-16k32k/json-default-think, test/gemma12b/C-gepa-16k32k/chat8192, test/gemma12b/C-gepa-16k32k/schema8192, test/gemma12b/C-gepa-16k32k/schema16384, test/gemma12b/C-gepa-16k32k/chat-default, test/gemma12b/C-gepa-16k32k/json-default, test/gemma12b/C-gepa-16k32k/chat-default-think, test/gemma12b/C-gepa-16k32k/json-default-think

Missing stages in present cohorts (35): dev/qwen/A-minimal-8k/chat8192/filtered-ordinary, dev/qwen/A-minimal-8k/chat8192/filtered-ordinary-noverify, dev/qwen/A-minimal-8k/chat8192/verified-qwen, dev/qwen/A-minimal-8k/chat8192/filtered-title-qv, dev/qwen/A-minimal-8k/chat8192/filtered-ordinary-qv, dev/gemma12b/A-minimal-8k/chat8192/filtered-ordinary, dev/gemma12b/A-minimal-8k/chat8192/filtered-ordinary-noverify, dev/gemma12b/A-minimal-8k/chat8192/filtered-ordinary-qv, test/qwen/A-minimal-8k/chat8192/filtered-ordinary, test/qwen/A-minimal-8k/chat8192/filtered-ordinary-noverify, test/qwen/A-minimal-8k/chat8192/verified-qwen, test/qwen/A-minimal-8k/chat8192/filtered-title-qv, test/qwen/A-minimal-8k/chat8192/filtered-ordinary-qv, test/qwen/A-minimal-8k/schema8192/filtered-ordinary, test/qwen/A-minimal-8k/schema8192/filtered-ordinary-noverify, test/qwen/A-minimal-8k/schema8192/verified-qwen, test/qwen/A-minimal-8k/schema8192/filtered-title-qv, test/qwen/A-minimal-8k/schema8192/filtered-ordinary-qv, test/qwen/B-minimal-16k32k/chat8192/filtered-ordinary, test/qwen/B-minimal-16k32k/chat8192/filtered-ordinary-noverify, test/qwen/B-minimal-16k32k/chat8192/verified-qwen, test/qwen/B-minimal-16k32k/chat8192/filtered-title-qv, test/qwen/B-minimal-16k32k/chat8192/filtered-ordinary-qv, test/gemma12b/A-minimal-8k/chat8192/filtered-ordinary, test/gemma12b/A-minimal-8k/chat8192/filtered-ordinary-noverify, test/gemma12b/A-minimal-8k/chat8192/filtered-ordinary-qv, dev/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-ordinary, dev/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-ordinary-noverify, dev/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-ordinary-qv, test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-ordinary, test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-ordinary-noverify, test/gemma12b/TR-bootstrap-16k32k/chat-default-think/filtered-ordinary-qv, test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-ordinary, test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-ordinary-noverify, test/gemma12b/TR-bootstrap-8k/chat-default-think/filtered-ordinary-qv
