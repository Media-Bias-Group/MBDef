# Outputs of the released code on the miniature inputs of some tests

On 20 Oct 2026, before #66 deleted the old `scripts/` and the old `src` modules from `dev`, the
released code was run once on the small made-up inputs that some tests build (the miniature grid of
`tests/mini_grid.py`, the miniature rows of `tests/mini_scoring.py`, the rows of
`tests/test_evaluate_heldout.py`). What it wrote is stored here. The tests compare the package's
output with these files (or give the gate the files as "the stored outputs"), so they still prove
that the package gives what the released code gave, without the released code in the tree.

| File | Made by | Read by |
|---|---|---|
| `heldout/mini-results.json`, `heldout/mini-results.md` | `scripts/test_eval_20260924_score.py` (sha256 a10702927c1f1ec2…), on the four miniature rows of `tests/mini_scoring.py`, with the ZIB run's paths written in as the stored copies have them | `tests/test_check_scoring.py` (row 4) |
| `heldout/rescoring.json` | the same script on the rows of `tests/test_evaluate_heldout.py` (with and without predictions, scored from `tests/fixtures/score-smoke.zip`'s pair scores), and its `apply_pick_rule` and `eligibility` on the cases listed there | `tests/test_evaluate_heldout.py` |
| `paired/output.txt` | `scripts/paired_ours_vs_opus.py` (sha256 1335042f694d8a7b…) on `tests/mini_scoring.paired_inputs` | `tests/test_check_scoring.py` (row 5), `tests/test_evaluate_paired.py` |
| `grid/mini-results.json`, `grid/environment.json` | `scripts/grid_20260925_score.py` (sha256 ff65c5ab3acd332c…): `evaluate` and `add_replicate` on the miniature grid, with a made-up pair scorer, and the environment values importing it set | `tests/test_evaluate_grid.py` |
| `selection/scoring-run/*`, `selection/reselection/*` | the same script's `evaluate` + `write_outputs` (with a first audit that wrongly flags the trained-prompt cohorts) and its `reselect` (with the corrected audit), on the miniature grid | `tests/test_check_selection.py` (row 3) |

Scripts and modules of the released code are on their archive branches and in the tag
`cleanup-base-2026-10-19` (`docs/archive/manifest.tsv` gives each file's branch):
`archive/final-extractor` (`scripts/test_eval_20260924_score.py`, `scripts/grid_20260925_score.py`),
`archive/paper-wiki` (`scripts/paired_ours_vs_opus.py`), and the kept `src/metrics.py` and
`src/benchmark/dspy_metric_selection.py` (shared).

Three placeholders stand for folders of the machine that wrote the outputs: `@MINI@` (the temporary
folder of the miniature grid) and `@REPO@` (the repository checkout, which the results name as the
place of the frozen reference files) in `grid/mini-results.json`, and `@TMP@` (the temporary folder of
the whole test) in `selection/`. The tests put their own folders in. The files are otherwise as the code wrote them: they hold
times and seconds that differ from run to run (the tests and the gate leave those out), and nothing was
edited by hand.

`recipe/` holds the three scripts that made the files, as they were run from the repository root of
`dev` at commit 99182ec with the old code still in place. They cannot run on a tree without the old
code; to remake the files, check out the base tag, copy the scripts' folder and run them there.
